document.write("Hello World!");
document.write(5+8);
document.write(25*5);
console.log("Hello World!")
let a=5;
let b=7;
let c=a*5+b+5;
console.log("The Value of c is",c);
console.log("The Value of a+b is",a+b);
let bikename;
bikename="Yamaha";
document.write(bikename)

{
var carname;
carname="xuv 700";
document.write(carname);
}
document.write(carname);
var x=10;
var y="hello world!";
var flag=true;
document.write(typeof(x));
document.write(typeof(y));
document.write(typeof(flag));
var num=35;
console.log (num,typeof(num));
var str="hello";
console.log (str,typeof(str));
var bool=String(true);
console.log (bool,typeof(bool));
//arithmatic operators +-*/%++--//
var x=6;
var y=4;
document.write("\n addition\n",x+y);
document.write("\n subtraction\n",x-y);
document.write("\n modulus\n",x-y);
document.write("\n division\n",x-y);
document.write("\n subtraction\n",x-y);