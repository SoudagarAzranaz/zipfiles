
function multiply(){
    let x;
    x=document.getElementById('x_value').value;
    console.log(typeof(x));
    x=Number(x);
    let y;
    y=document.getElementById('y_value').value;
    console.log(typeof(y));
    y=Number(y);
    let z=x*y;
    document.getElementById('multiplication').innerHTML=z;

}
function subtract(){
    let x;
    x=25;
    let y;
    y=15;
   let z=x-y;
    document.getElementById('subtraction').innerHTML=z;


}

function sub(){
let x;
 x=document.getElementById('x_value').value;
console.log(typeof(x));
x=Number(x);
 let y;
y=document.getElementById('y_value').value;
console.log(typeof(y));
y=Number(y);
let z=x-y;
document.getElementById('subtract').innerHTML=z;

}